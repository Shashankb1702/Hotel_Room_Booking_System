<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = ""; // Update with your MySQL password
$dbname = "hotel_booking";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Fetch all bookings
$sql = "SELECT * FROM bookings";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Room Bookings</title>
    <link rel="stylesheet" href="css/adminTable.css">
</head>

<body>
    <div class="filter">

    </div>
    
         
         <h2  class="head">All Bookings</h2>
        <table border="1">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Moblie No</th>
            <th>check in</th>
            <th>check out</th>
            <th>room type</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["id"] . "</td>";
                echo "<td>" . $row["name"] . "</td>";
                echo "<td>" . $row["email"] . "</td>";
                echo "<td>" . $row["mobileno"] . "</td>";
                echo "<td>" . $row["checkin"] . "</td>";
                echo "<td>" . $row["checkout"] . "</td>";                
                echo "<td>" . $row["roomtype"] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>No bookings found</td></tr>";
        }
        ?>
        </table>
   
</body>
</html>

<?php
$conn->close();
?>