<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel_booking";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];    
    $mobileno = $_POST['phone'];
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];
    $roomtype = $_POST['room'];


    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO bookings (name, email, mobileno, checkin, checkout, roomtype) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $name, $email,$mobileno, $checkin, $checkout, $roomtype);

    // Execute and check for success
    if ($stmt->execute()) {
        echo "Booked successfully!";
        header("location:homepage.html");
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
*