<?php
// Start the session
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel_booking";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Assume you have a form that sends 'username' and 'password' via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form inputs
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query the database to check if the user exists
    $stmt = $conn->prepare('SELECT id, password FROM usersadmin WHERE username = ?');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Bind the result to variables
        $stmt->bind_result($id, $hashed_password);
        $stmt->fetch();

        // Verify the password
        if (($password == $hashed_password)) {
            // Store user_id in session
            $user_id = $id;

            // Redirect to a protected page
            header('Location: display.php');
            exit();
        } else {
            echo 'Invalid password';
            header('Location: admin_login.html');
        }
    } else {
        echo 'No user found with that username';
    }

    // Close the statement
    $stmt->close();
}

// Close the connection
$conn->close();
?>