<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel_booking";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $mobileno = $_POST['mobileno'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Input validation
    if (empty($username) || empty($mobileno) || empty($email) || empty($password)) {
        echo "All fields are required.";
        exit();
    }

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO users (username, moblieno, email, password) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $username, $mobileno,$email, $password);

    // Execute and check for success
    if ($stmt->execute()) {
        echo "Registration successful!";
        header("location:Userlogin.html");
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
*